from input import ask
from domains.GPA import GPA

def student_list(stdscr, students):
    stdscr.clear()
    for st in students:
        stdscr.addstr(f"ID: {st.id} | Name: {st.name} | DoB: {st.dob}\n")
    stdscr.getch()

def course_list(stdscr, course):
    stdscr.clear()
    for c in course:
        stdscr.addstr(f"ID: {c.id} | Subject: {c.name} | Credit: {c.credit}\n")
    stdscr.getch()

def mark_list(stdscr, marks):
    stdscr.clear()
    for s_id in marks:
        for st_id, mark in marks[s_id].items():
            stdscr.addstr(f"Subject ID: {s_id} | Student ID: {st_id} | Score: {mark}\n")
    stdscr.getch()

def show_gpa(stdscr, marks, course):
    stdscr.clear()
    sid = int(ask(stdscr, "Student ID: "))
    stdscr.addstr(f"\nGPA: {GPA(sid, marks, course):.2f}\n")
    stdscr.getch()

def sort_GPA(stdscr, students, marks, course):
    students.sort(key=lambda st: GPA(st.id, marks, course), reverse=True)
    stdscr.clear()
    for st in students:
        stdscr.addstr(f"{st.name} | {GPA(st.id, marks, course):.2f}\n")
    stdscr.getch()