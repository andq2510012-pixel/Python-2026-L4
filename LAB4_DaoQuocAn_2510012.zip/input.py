import curses
import math
import numpy as np

from domains.student import Student
from domains.course import Course 

def ask(stdscr, prompt):
    stdscr.addstr(prompt)
    curses.echo()
    s = stdscr.getstr().decode()
    curses.noecho()
    return s

def students_info(stdscr, students):
    stdscr.clear()
    n = int(ask(stdscr, "Number of student: "))
    for _ in range(n):
        stdscr.addstr("\n")
        i_id = int(ask(stdscr, "id: "))
        i_name = ask(stdscr, "name: ")
        i_dob = ask(stdscr, "Date of birth: ")
        students.append(Student(i_id, i_name, i_dob))

    with open("students.txt", "w", encoding="utf-8") as f:
        for s in students:
            f.write(f"{s.id},{s.name},{s.dob}\n")  

def courses(stdscr, course):
    stdscr.clear()
    num_course = int(ask(stdscr, "Number of courses: "))
    for _ in range(num_course):
        stdscr.addstr("\n")
        s_id = int(ask(stdscr, ("id: ")))
        s_name = str(ask(stdscr, "name: "))
        s_credit = int(ask(stdscr, "credit: "))
        course.append(Course(s_id, s_name, s_credit))

    with open("courses.txt", "w", encoding="utf-8") as f:
        for c in course:
            f.write(f"{c.id},{c.name},{c.credit}\n")

def mark_student(stdscr, students, course, marks):
    stdscr.clear()
    s_id = int(ask(stdscr, "subject ID: "))
    if s_id in [c.id for c in course]:
        marks.setdefault(s_id, {})
        for st in students:
            stdscr.addstr("\n")
            mark = math.floor(float(ask(stdscr, f"Score of {st.name}: ")))
            marks[s_id][st.id] = mark

    with open("marks.txt", "w", encoding="utf-8") as f:
        for cid, d in marks.items():
            for sid, m in d.items():
                f.write(f"{cid},{sid},{m}\n")
    

