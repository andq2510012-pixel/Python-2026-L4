import numpy as np

def GPA(student_id, marks, course):
    cr = {c.id: c.credit for c in course}
    ids = [s for s in marks if student_id in marks[s]]
    if not ids:
        return 0.0
    c = np.array([cr[s] for s in ids], dtype=float)
    m = np.array([marks[s][student_id] for s in ids], dtype=float)
    return np.dot(c, m) / np.sum(c)