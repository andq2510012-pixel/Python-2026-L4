from domains.student import Student

s = Student(101, "An", "2005-01-01")
print(s.name)
