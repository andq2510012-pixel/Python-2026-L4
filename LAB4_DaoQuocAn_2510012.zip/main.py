import curses
from input import ask, students_info, courses, mark_student
from output import student_list, course_list, mark_list, show_gpa, sort_GPA
from output import compress, decompress

students = []
course = []
marks = {}

def main(stdscr):
    stdscr.scrollok(True)
    while True:
        stdscr.clear()
        stdscr.addstr("1. Student info\n")
        stdscr.addstr("2. Course info\n")
        stdscr.addstr("3. Mark\n")
        stdscr.addstr("4. Student list\n")
        stdscr.addstr("5. Course list\n")
        stdscr.addstr("6. Mark list\n")
        stdscr.addstr("7. GPA of a student\n")
        stdscr.addstr("8. Students sorted by GPA\n")
        stdscr.addstr("0. Exit\n\n")

        try:
            a = int(ask(stdscr, "Choose 0-8: "))
        except ValueError:
            continue

        if a == 0:
            break
        elif a == 1:
            students_info(stdscr, students)
        elif a == 2:
            courses(stdscr, course)
        elif a == 3:
            mark_student(stdscr, students, course, marks)
        elif a == 4:
            student_list(stdscr, students)
        elif a == 5:
            course_list(stdscr, course)
        elif a == 6:
            mark_list(stdscr, marks)
        elif a == 7:
            show_gpa(stdscr, marks, course)
        elif a == 8:
            sort_GPA(stdscr, students, marks, course)

    actions = {"1": lambda: students_info(stdscr, students),
               "2": lambda: courses(stdscr, course),
               "3": lambda: mark_student(stdscr, students, course, marks)}

    decompress()
    try:
        while True:
            stdscr.clear()
            stdscr.addstr("1. Input students\n2. Input courses\n3. Mark\n0. Exit\n")
            c = ask(stdscr, "Choose: ")
            if c == "0":
                break
            actions.get(c, lambda: None)()
    finally:
        compress()

if __name__ == "__main__":
    curses.wrapper(main)

